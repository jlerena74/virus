# Monoxide-peaceful
WHYPETのMonoxideを無害化したもの
完全に無害化されている保証はないため、
実行は自己責任でお願いします。
